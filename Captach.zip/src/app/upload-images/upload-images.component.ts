import { Component, OnInit } from '@angular/core';
import { FormControl,ReactiveFormsModule, FormGroup } from '@angular/forms';
import { UploadImageService } from '../Shared/upload-image.service';

@Component({
  selector: 'app-upload-images',
  templateUrl: './upload-images.component.html',
  styleUrls: ['./upload-images.component.css']
})
export class UploadImagesComponent implements OnInit {
  Upload:FormGroup;
  files: any[] = [];
  formData1:FormData;
  constructor(private restDataServices:UploadImageService) {
    this.Upload= new FormGroup({
      'photos':new FormControl(),
      'Name':new FormControl(),
      'Tags':new FormControl
    })
   }
  
  ngOnInit(): void {
  }
  onSubmit(value){
    //console.log(value);
    this.formData1 = new FormData();
		this.formData1.append(this.files[0].name, this.files[0])
    this.formData1.append("Name",value.value["Name"]);
    this.formData1.append("Tags",value.value["Tags"]);
    
		this.restDataServices.PostData(this.formData1).subscribe(
			resp => {
				console.log("Document Uploaded");
				console.log(resp);
			});
  }
  fileBrowseHandler(value){
    this.files=[];
    this.files.push(value["target"]["files"][0]);
  }
}
