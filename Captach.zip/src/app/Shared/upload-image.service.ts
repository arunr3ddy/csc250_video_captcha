import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class UploadImageService {
  endpoint="http://localhost:1391/";
  constructor(private http:HttpClient) { }

  PostData(value){
    const url=this.endpoint+"api/UploadImage"
    const body =value;
    return this.http.post(url,body);
  }
  getImage(number){
    const url=this.endpoint+"api/GetImage"
    return this.http.post(url,number);
  }
  GetDropDown(){
    const url=this.endpoint+"api/GetDropDown"
    return this.http.post(url,"");
  }
  CheckCaptacha(value){
    const url=this.endpoint+"api/CheckCaptacha"
    return this.http.post(url,value);
  }
  AddData(value){
    const url=this.endpoint+"api/AddData"
    return this.http.post(url,value);
  }
}
